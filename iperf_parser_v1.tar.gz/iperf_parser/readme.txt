=====================================
Details for using iPerf parser
=====================================

1. Description
   IPERF parser can be used to print the iperf command output in the following formats
       1. Textfsm fsm table (Default)
       2. Json
       3. Yaml
2. Prerequisites
      1. Python interpreter
      2. iPerf tool 
      3. iPerf server and client machines

3. Files required
      1. Textfsm template file (templateIperfCli)
      2. Data file (inputData.yml)
      3. Parser library (textfsmParserLib.py)
      4. IPERF Parser script (IPERF_Parser.py)

4. Dependend packages required
      1. textfsm (pip install textfsm)
      2. pyyaml

5. System packages required
      1. json
      2. sys
      3. argparse
      4. itertools
      5. signal

6. Modifications required
      1. Modify Data file (inputData.yml) to point to the textfsm template location (templateIperfCli)

7. Sample Usage

./IPERF_Parser.py -h
usage: IPERF_Parser.py [-h] [--json] [--yaml]

optional arguments:
  -h, --help  show this help message and exit
  --json      Print output in json format
  --yaml      Print output in yaml format

JSON OUTPUT

[nithinf@iperfclient iperf]$ iperf -c 10.160.0.2 | ./IPERF_Parser.py --json


==============================
JSON FORMATTED OUTPUT
==============================
{
    "3": {
        "bandwidth": "1.94 Gbits/sec", 
        "interval": "0.0-10.0 sec", 
        "localHost": "10.160.0.3", 
        "localPort": "34210", 
        "remoteHost": "10.160.0.2", 
        "remotePort": "5001", 
        "transfer": "2.26 GBytes"
    }
}

YAML OUTPUT

[nithinf@iperfclient iperf]$ iperf -c 10.160.0.2 | ./IPERF_Parser.py --yaml


==============================
YAML FORMATTED OUTPUT
==============================
'3':
    bandwidth: 1.94 Gbits/sec
    interval: 0.0-10.0 sec
    localHost: 10.160.0.3
    localPort: '34212'
    remoteHost: 10.160.0.2
    remotePort: '5001'
    transfer: 2.26 GBytes



FSM TABLE OUTPUT

[nithinf@iperfclient iperf]$ iperf -c 10.160.0.2 | ./IPERF_Parser.py


==============================
Textfsm FSM table
==============================
['socket', 'localHost', 'localPort', 'remoteHost', 'remotePort', 'interval', 'transfer', 'bandwidth']
['3', '10.160.0.3', '34216', '10.160.0.2', '5001', '0.0-10.0 sec', '2.27 GBytes', '1.95 Gbits/sec']

