#!/usr/bin/env python

#Import the required packages
import sys
import json
import yaml
import argparse
import textfsm_parser_lib


class Print_output():
    '''class to print cli output in various formats'''

    def __init__(self,yaml_flag,json_flag,fsm_output,dict_output):
        '''Initialization method to intialize the variables'''

        self.yaml_flag = yaml_flag
        self.json_flag = json_flag
        self.fsm_output = fsm_output
        self.dict_output = dict_output
   
    def formatted_output(self):
        '''method to print the cli output'''

        print "\n\n","="*30
        if self.json_flag == False and self.yaml_flag == False:
            print "Textfsm FSM table"
            print "="*30
            print self.fsm_output
        if self.json_flag:
            print "JSON FORMATTED OUTPUT"
            print "="*30
            json_output = json.dumps(self.dict_output,sort_keys=True,indent=4)
            print json_output
        if self.yaml_flag:
            print "YAML FORMATTED OUTPUT"
            print "="*30
            yaml_output = yaml.dump(self.dict_output,default_flow_style=False,indent=4)
            print yaml_output
    
        
def main():
    '''main function'''

    #Use argparse and set the required arguments
    parser=argparse.ArgumentParser()
    #argument to print output in json format
    parser.add_argument("--json", help="Print output in json format",
                        action="store_true")
    #argument to print output in yaml format
    parser.add_argument("--yaml", help="Print output in json format",
                        action="store_true")
    args=parser.parse_args()
    #Read the cli output from the piped process
    cli_output = sys.stdin.read()
    #Read the input data yaml file to get the textfsm template location
    with open('input_data.yml','r') as input_file:
        input_data = yaml.load(input_file)
        template = input_data['template']
    #create cli parser object and convert cli output to fsm table and dictionary
    cli_parser = textfsm_parser_lib.Textfsm_parser(template,cli_output)
    iperf_output_fsm = cli_parser.output_parser()
    iperf_output_dict = cli_parser.convert_fsm_to_dictionary()
    #print cli output according to user input
    print_output = Print_output(args.yaml,args.json,iperf_output_fsm,iperf_output_dict)
    print_output.formatted_output()

if __name__ == "__main__":
    main()
