##########################################################################
# Description : Lib for parsing cli output using textfsm and to generate
#               the fsm table and dictionary
# Developer   : Jose Fernandez
# Date        : 21-Mar-2018 
##########################################################################

# Import the required packages

import itertools

import textfsm


class TextfsmParser():

    """
    Class to parse cli output with the textfsm template and 
    generate the fsm table and dictionary
    """

    def __init__(self,template,output):

        """
        Function Name        : __init__
        Function Description : Constructor function to initialize class
        Inputs   : 
                self     - Class instance
                template - Textfsm template file for the cli
                output   - Command output for cli parsing
        Outputs  : None
        """

        self.template = template
        self.output = output

    def outputParser(self):

        """
        Function Name        : outputParser
        Function Description : Method to convert cli output into fsm table
        Inputs   : 
                self - Class instance
        Outputs  :
                result - Textfsm fsm table
        """

        templateFile = open(self.template)
        self.fsm = textfsm.TextFSM(templateFile)
        self.table = self.fsm.ParseText(self.output)
        templateFile.close()
        result = str(self.fsm.header) + '\n'
        for line in self.table:
            result += str(line) + '\n'

        return result

    def convertFsmToDictionary(self):

        """
        Function Name        : convertFsmToDictionary
        Function Description : Method to convert fsm output into dictionary
        Inputs   : 
                self - Class instance
        Outputs  :
                outputDict - Output in dictionary format
        """

        outputDict = {}
        tableHeader = self.fsm.header[:] 
        tableHeader.pop(0)
        for eachRow in self.table:
            mainKey = eachRow.pop(0)
            outputDict[mainKey] = {}
            for key,value in itertools.izip(tableHeader,eachRow):
                outputDict[mainKey][key] = value

        return outputDict



##########################################################################
# Revision No  Author	         Date      Reason for Modification
# 1.0          Jose Fernandez  21-Mar-2018  Created lib file
# 1.1          Jose Fernandez  22-Mar-2018  Implemented coding standards
##########################################################################
  
