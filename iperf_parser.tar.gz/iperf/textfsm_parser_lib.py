#Import the required packages

import textfsm
import itertools

class Textfsm_parser():
    '''
    class to parse cli output with the textfsm template and 
    generate the fsm table and dictionary
    '''

    def __init__(self,template,output):
        '''initialize the variables'''

        self.template = template
        self.output = output

    def output_parser(self):
        '''method to convert the cli output into fsm table'''

        template_file = open(self.template)
        self.fsm = textfsm.TextFSM(template_file)
        self.table = self.fsm.ParseText(self.output)
        result = str(self.fsm.header) + '\n'
        for line in self.table:
            result += str(line) + '\n'
        return result

    def convert_fsm_to_dictionary(self):
        '''method to convert fsm output into dictionary format'''

        output_dict = {}
        self.fsm.header.pop(0)
        for each_row in self.table:
            main_key = each_row.pop(0)
            output_dict[main_key] = {}
            for key,value in itertools.izip(self.fsm.header,each_row):
                output_dict[main_key][key] = value
        return output_dict
  
